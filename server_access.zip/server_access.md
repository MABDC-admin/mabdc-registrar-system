# MABDC Server Access Details

This file contains the connection details for both of the production servers hosted on Hetzner.

## 📊 Server 1: Finance & Database Server

*   **Hostname/Label**: `finance-db-server`
*   **Public IP**: `2.28.30.85`
*   **Hetzner Private IP (vSwitch)**: `10.0.0.2`
*   **ZeroTier IP**: `10.121.15.111`
*   **SSH Port**: `22`
*   **SSH User**: `root`
*   **SSH Key File**: `hetzner_id_ed25519`
*   **Database (PostgreSQL)**: Runs locally on port `5432`

### Connection Command:
```bash
ssh -i hetzner_id_ed25519 root@2.28.30.85
```

---

## 🖥️ Server 2: Registrar & Application Server

*   **Hostname/Label**: `registrar-app-server`
*   **Public IP**: `2.28.22.242`
*   **Hetzner Private IP (vSwitch)**: `10.0.0.3`
*   **ZeroTier IP**: `10.121.15.87`
*   **SSH Port**: `22`
*   **SSH User**: `root`
*   **SSH Key File**: `hetzner_id_ed25519`

### Connection Command:
```bash
ssh -i hetzner_id_ed25519 root@2.28.22.242
```

---

## 🔑 SSH Key Information

The SSH key included in this folder (`hetzner_id_ed25519`) is the private key required to authenticate as `root` on both servers.

### Security Warning:
Keep this private key secure. Anyone with access to this key can gain full root access to both servers.

### Permissions Notice:
Before using the SSH key on Linux/macOS, you must set the correct permissions:
```bash
chmod 400 hetzner_id_ed25519
```
On Windows (PowerShell), you can restrict access using the Security properties tab or Windows ACL.
